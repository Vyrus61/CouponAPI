﻿using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.Builder;
using MinimalApiDemo.Models.DTO;
using MinimalApiDemo.Models;
using MinimalApiDemo.Repository.IRepository;
using MinimalApiDemo.Coupons;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Win32;

namespace MinimalApiDemo.Endpoints
{
    public static class AuthEndpoints
    {
        public static void ConfigureAuthEndpoints(this WebApplication app)
        {

            app.MapPost("/api/login", Login).WithName("Login").Accepts<LoginRequestDTO>("application/json")
                .Produces<APIResponse>(200).Produces(400);
            app.MapPost("/api/register", Register).WithName("Register").Accepts<RegisterationRequestDTO>("application/json")
                .Produces<APIResponse>(200).Produces(400);
        }

        private async static Task<IResult> Register(IAuthRepository _authRepo,
            [FromBody] RegisterationRequestDTO model)
        {
            APIResponse response = new() { IsSuccess = false, StatusCode = HttpStatusCode.BadRequest };


            bool ifUserNameisUnique = _authRepo.IsUniqueUser(model.UserName);
            if (!ifUserNameisUnique)
            {
                response.ErrorMessages.Add("Username already exists");
                return Results.BadRequest(response);
            }
            var registerResponse = await _authRepo.Register(model);
            if (registerResponse == null || string.IsNullOrEmpty(registerResponse.UserName))
            {

                return Results.BadRequest(response);
            }

            response.IsSuccess = true;
            response.StatusCode = HttpStatusCode.OK;
            return Results.Ok(response);

        }

        private async static Task<IResult> Login(IAuthRepository _authRepo,
           [FromBody] LoginRequestDTO model)
        {
            APIResponse response = new() { IsSuccess = false, StatusCode = HttpStatusCode.BadRequest };
            var loginResponse = await _authRepo.Login(model);
            if (loginResponse == null)
            {
                response.ErrorMessages.Add("Username or password is incorrect");
                return Results.BadRequest(response);
            }
            response.Result = loginResponse;
            response.IsSuccess = true;
            response.StatusCode = HttpStatusCode.OK;
            return Results.Ok(response);

        }
    }
}
