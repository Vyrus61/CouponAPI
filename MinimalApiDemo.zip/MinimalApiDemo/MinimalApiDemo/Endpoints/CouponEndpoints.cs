﻿using AutoMapper;
using FluentValidation;
using Microsoft.AspNetCore.Builder;
using MinimalApiDemo.Models.DTO;
using MinimalApiDemo.Models;
using MinimalApiDemo.Repository.IRepository;
using MinimalApiDemo.Coupons;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace MinimalApiDemo.Endpoints
{
    public static class CouponEndpoints
    {
        public static void ConfigureCouponEndpoints(this WebApplication app)
        {

            app.MapGet("/api/coupon", GetAllCoupon).WithName("GetCoupons").Produces<APIResponse>(200).RequireAuthorization("AdminOnly");

            app.MapGet("/api/coupon{id=int}", GetCoupon).WithName("GetCoupon").Produces<APIResponse>(200).AddEndpointFilter(async (context, next) =>
            {
                var id = context.GetArgument<int>(2);
                if (id == 0)
                {
                    return Results.BadRequest("Connot have 0 in id");
                }
                return await next(context);
            });

            app.MapPost("/api/coupon", CreateCoupon).WithName("CreateCoupon").Accepts<CouponCreateDTO>("application/json").Produces<APIResponse>(201).Produces(400);

            app.MapPut("/api/coupon", UpdateCoupon).WithName("UpdateCoupon").Accepts<CouponUpdateDTO>("application/json").Produces<APIResponse>(201).Produces(400);

            app.MapDelete("/api/coupon{id=int}", DeleteCoupon).WithName("DeleteCoupon").Produces<APIResponse>(201).Produces(400);

        }
        [Authorize]
        private async static Task<IResult> GetCoupon(ICouponRepository _couponRepo, int id)
        {
            APIResponse response = new APIResponse();
            response.Result = await _couponRepo.GetAsync(id);
            response.IsSuccess = true;
            response.StatusCode = System.Net.HttpStatusCode.OK;
            return Results.Ok(response);
        }
        [Authorize]
        private async static Task<IResult> CreateCoupon(ICouponRepository _couponRepo, IMapper _mapper, IValidator<CouponCreateDTO> _validation, [FromBody] CouponCreateDTO couponCreatedDTO)
        {

            APIResponse response = new() { IsSuccess = false, StatusCode = HttpStatusCode.BadRequest };


            var validationResult = await _validation.ValidateAsync(couponCreatedDTO);
            if (!validationResult.IsValid)
            {
                response.ErrorMessages.Add(validationResult.Errors.FirstOrDefault().ToString());
                return Results.BadRequest(response);
            }
            Coupon coupon = _mapper.Map<Coupon>(couponCreatedDTO);


            if (_couponRepo.GetAsync(couponCreatedDTO.Name).GetAwaiter().GetResult() != null)
            {
                response.ErrorMessages.Add("Name exists");
                return Results.BadRequest(response);
            }

            await _couponRepo.CreateAsync(coupon);
            await _couponRepo.SaveAsync();
            CouponDTO couponDTO = _mapper.Map<CouponDTO>(coupon);

            response.Result = couponDTO;
            response.IsSuccess = true;
            response.StatusCode = System.Net.HttpStatusCode.Created;
            return Results.Ok(response);
        }
        [Authorize]
        private async static Task<IResult> UpdateCoupon(ICouponRepository _couponRepo, IMapper _mapper, IValidator<CouponUpdateDTO> _validation, [FromBody] CouponUpdateDTO couponUpdateDTO)
        {

            APIResponse response = new() { IsSuccess = false, StatusCode = HttpStatusCode.BadRequest };


            var validationResult = await _validation.ValidateAsync(couponUpdateDTO);
            if (!validationResult.IsValid)
            {
                response.ErrorMessages.Add(validationResult.Errors.FirstOrDefault().ToString());
                return Results.BadRequest(response);
            }
            await _couponRepo.UpdateAsync(_mapper.Map<Coupon>(couponUpdateDTO));
            await _couponRepo.SaveAsync();
            response.Result = _mapper.Map<CouponDTO>(await _couponRepo.GetAsync(couponUpdateDTO.Id));
            response.IsSuccess = true;
            response.StatusCode = System.Net.HttpStatusCode.OK;
            return Results.Ok(response);
        }
        [Authorize]
        private async static Task<IResult> DeleteCoupon(ICouponRepository _couponRepo, int id)
        {


            APIResponse response = new() { IsSuccess = false, StatusCode = HttpStatusCode.BadRequest };
            Coupon couponFromStore = await _couponRepo.GetAsync(id);
            if (couponFromStore != null)
            {
                await _couponRepo.RemoveAsync(couponFromStore);
                await _couponRepo.SaveAsync();
                response.IsSuccess = true;
                response.StatusCode = System.Net.HttpStatusCode.OK;
                return Results.Ok(response);
            }
            else
            {
                response.ErrorMessages.Add("Invalid Id");
                return Results.BadRequest(response);
            }

        }
        [Authorize]
        private async static Task<IResult> GetAllCoupon(ICouponRepository _couponRepo)
        {

            APIResponse response = new APIResponse();
            response.Result = await _couponRepo.GetAllAsync();
            response.IsSuccess = true;
            response.StatusCode = System.Net.HttpStatusCode.OK;
            return Results.Ok(response);
        }
    }
}
